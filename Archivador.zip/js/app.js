function joinGroup() {
  window.open(
    "https://api.whatsapp.com/send?phone=5215560318196&text=Hola%20buenas%20%F0%9F%91%8B%0AEstoy%20interesado%20en%20las%20clases%20de%20Programaci%C3%B3n%20Orientada%20a%20Objetos%2C%20cuando%20abres%20grupo%20nuevo%3F%3F%3F",
    "_blank"
  );
}
function joinChatP0() {
  window.location.href = "https://api.whatsapp.com/send?phone=5215560318196&text=Hola%20vi%20tu%20p%C3%A1gina%20y%20me%20interes%C3%B3%20inscribirme%20el%20curso%20de%20programaci%C3%B3n%20desde%200%20%F0%9F%A4%97%20me%20puedes%20proporcionar%20la%20info%20de%20inscripci%C3%B3n%3F%3F%3F";
}
